const JSON_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*"
};

function response(statusCode, body) {
  return {
    statusCode,
    headers: JSON_HEADERS,
    body: JSON.stringify(body)
  };
}

function stripHtml(html = "") {
  return String(html)
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, "&")
    .replace(/\s+/g, " ")
    .trim();
}

function money(value) {
  const num = Number(String(value || "").replace(/[^\d.]/g, ""));
  if (!Number.isFinite(num) || num <= 0) return "";
  return num.toFixed(2).replace(/\.00$/, "");
}

function guessCategory(text = "") {
  const t = text.toLowerCase();
  if (/clorox|bleach|clean|disinfect|laundry|spray|wipes|detergent|soap|dish/.test(t)) return "Cleaning";
  if (/baby|bottle|wipe|diaper|stroller|car seat|pacifier|formula/.test(t)) return "Baby";
  if (/makeup|hair|skin|beauty|shampoo|conditioner|curl|dryer|serum|cream|lotion|mascara|foundation/.test(t)) return "Beauty";
  if (/vacuum|air fryer|blender|coffee|espresso|humidifier|fan|heater|appliance|kitchen appliance/.test(t)) return "Appliances";
  if (/toy|game|lego|doll|puzzle|uno|play/.test(t)) return "Toys";
  if (/speaker|headphone|charger|phone|watch|electronic|usb|cable|battery/.test(t)) return "Electronics";
  if (/food|snack|drink|candy|chips|grocery|cereal|sauce|cookie|protein/.test(t)) return "Food";
  if (/vitamin|medicine|health|toothpaste|mouthwash|first aid|bandage/.test(t)) return "Health";
  if (/kitchen|pan|pot|cookware|bakeware|container|cup|bottle/.test(t)) return "Kitchen";
  if (/home|blanket|pillow|sheet|decor|storage|lamp/.test(t)) return "Home";
  return "Other";
}

function estimateRetail(title = "", category = "") {
  const t = `${title} ${category}`.toLowerCase();
  if (/bleach|spray|wipes|cleaner|clorox/.test(t)) return "8";
  if (/detergent|laundry/.test(t)) return "16";
  if (/mouthwash|toothpaste|deodorant|soap|shampoo|conditioner/.test(t)) return "9";
  if (/vacuum|shark|dyson/.test(t)) return "299";
  if (/ninja|air fryer|blender|coffee|espresso/.test(t)) return "179";
  if (/baby brezza|bottle warmer|wipe warmer/.test(t)) return "79";
  if (/baby/.test(t)) return "49";
  if (/beauty|hair|curl|dryer|straightener/.test(t)) return "89";
  if (/toy|game|lego/.test(t)) return "24";
  if (/electronics|speaker|headphone|charger/.test(t)) return "39";
  return "29";
}

async function fetchText(url, timeoutMs = 10000) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: {
        "User-Agent": "Mozilla/5.0 ReyLiquidationApp/1.0"
      }
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.text();
  } finally {
    clearTimeout(timeout);
  }
}

async function fetchJson(url, timeoutMs = 10000) {
  const text = await fetchText(url, timeoutMs);
  return JSON.parse(text);
}

async function lookupUPCItemDB(barcode) {
  const data = await fetchJson(`https://api.upcitemdb.com/prod/trial/lookup?upc=${encodeURIComponent(barcode)}`);
  const item = data.items && data.items[0];
  if (!item || !item.title) return null;

  let highest = "";
  const offerLines = [];

  if (Array.isArray(item.offers)) {
    let max = 0;
    for (const offer of item.offers) {
      const n = Number(String(offer.price || "").replace(/[^\d.]/g, ""));
      if (n > max) max = n;
      if (offer.merchant || offer.price) {
        offerLines.push(`${offer.merchant || "Store"}${offer.price ? " - $" + money(offer.price) : ""}`);
      }
    }
    if (max) highest = String(Math.ceil(max));
  }

  const description = [
    item.brand ? `Brand: ${item.brand}.` : "",
    item.model ? `Model: ${item.model}.` : "",
    item.description || ""
  ].filter(Boolean).join(" ");

  const category = guessCategory(`${item.title} ${item.description || ""} ${item.category || ""} ${item.brand || ""}`);
  const retailPrice = highest || estimateRetail(item.title, category);

  return {
    title: item.title,
    description,
    category,
    retailPrice,
    image: Array.isArray(item.images) ? item.images[0] : "",
    source: "UPCitemdb",
    priceEvidence: offerLines,
    notes: [
      "Source: UPCitemdb",
      highest ? `Highest price found in free offers: $${highest}` : "Exact retail not found; retail is estimated.",
      offerLines.length ? `Store offers:\n${offerLines.slice(0, 8).join("\n")}` : ""
    ].filter(Boolean).join("\n\n")
  };
}

function normalizeOpenFactsProduct(product, source) {
  const title = product.product_name || product.product_name_en || product.generic_name || product.abbreviated_product_name || "";
  if (!title) return null;

  const description = [
    product.brands ? `Brand: ${product.brands}.` : "",
    product.quantity ? `Size: ${product.quantity}.` : "",
    product.generic_name ? `${product.generic_name}.` : "",
    product.categories ? `Category: ${product.categories}.` : "",
    product.ingredients_text ? `Details: ${String(product.ingredients_text).slice(0, 220)}.` : ""
  ].filter(Boolean).join(" ");

  const image =
    product.image_front_url ||
    product.image_url ||
    product.selected_images?.front?.display?.en ||
    product.selected_images?.front?.small?.en ||
    "";

  const category = guessCategory(`${title} ${product.categories || ""} ${product.brands || ""}`);
  const retailPrice = estimateRetail(title, category);

  return {
    title,
    description,
    category,
    retailPrice,
    image,
    source,
    priceEvidence: [],
    notes: `Source: ${source}\nExact retail was not included by this free database, so retail is estimated.`
  };
}

async function lookupOpenFacts(barcode, host, source) {
  const data = await fetchJson(`https://${host}/api/v2/product/${encodeURIComponent(barcode)}.json`);
  if (data.status !== 1 || !data.product) return null;
  return normalizeOpenFactsProduct(data.product, source);
}

function extractDuckResults(html) {
  const results = [];
  const regex = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?<a[^>]+class="result__snippet"[^>]*>([\s\S]*?)<\/a>/gi;
  let match;

  while ((match = regex.exec(html)) && results.length < 12) {
    let url = match[1];
    try {
      const parsed = new URL(url, "https://duckduckgo.com");
      const uddg = parsed.searchParams.get("uddg");
      if (uddg) url = decodeURIComponent(uddg);
    } catch {}
    results.push({
      url,
      title: stripHtml(match[2]),
      snippet: stripHtml(match[3])
    });
  }

  return results;
}

function extractPrices(text) {
  const prices = [];
  const regex = /\$\s?([0-9]{1,4}(?:,[0-9]{3})?(?:\.[0-9]{2})?)/g;
  let match;
  while ((match = regex.exec(text)) && prices.length < 50) {
    const value = Number(match[1].replace(",", ""));
    if (value >= 1 && value <= 5000) prices.push(value);
  }
  return prices;
}

async function retailSearch(barcode, knownTitle = "") {
  const retailers = [
    "target.com",
    "walmart.com",
    "amazon.com",
    "homedepot.com",
    "lowes.com",
    "bestbuy.com",
    "kohls.com",
    "wayfair.com",
    "costco.com",
    "samsclub.com"
  ];

  const query = `${barcode} ${knownTitle} (${retailers.map(r => "site:" + r).join(" OR ")})`;
  const url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`;
  const html = await fetchText(url);
  const results = extractDuckResults(html);

  const priceEvidence = [];
  let highest = 0;
  let bestTitle = knownTitle || "";

  for (const result of results) {
    const combined = `${result.title} ${result.snippet}`;
    const prices = extractPrices(combined);
    const localMax = prices.length ? Math.max(...prices) : 0;

    if (localMax > highest) highest = localMax;
    if (!bestTitle && result.title) bestTitle = result.title.replace(/\s+\|.+$/, "").replace(/\s+-\s+.+$/, "");

    if (localMax) {
      let host = "";
      try { host = new URL(result.url).hostname.replace("www.", ""); } catch {}
      priceEvidence.push(`${host || "Retail result"} - $${money(localMax)}\n${result.title}\n${result.url}`);
    }
  }

  return {
    highest: highest ? String(Math.ceil(highest)) : "",
    bestTitle,
    results,
    priceEvidence
  };
}

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return response(200, {});

  const barcode = event.queryStringParameters?.barcode;
  if (!barcode) return response(400, { error: "Missing barcode" });

  const searched = [];
  let product = null;

  const databaseAttempts = [
    ["UPCitemdb", () => lookupUPCItemDB(barcode)],
    ["Open Food Facts", () => lookupOpenFacts(barcode, "world.openfoodfacts.org", "Open Food Facts")],
    ["Open Beauty Facts", () => lookupOpenFacts(barcode, "world.openbeautyfacts.org", "Open Beauty Facts")],
    ["Open Products Facts", () => lookupOpenFacts(barcode, "world.openproductsfacts.org", "Open Products Facts")]
  ];

  for (const [name, lookup] of databaseAttempts) {
    try {
      searched.push(name);
      const found = await lookup();
      if (found && found.title) {
        product = found;
        break;
      }
    } catch (error) {
      searched.push(`${name} failed`);
    }
  }

  try {
    searched.push("Retail web search");
    const retail = await retailSearch(barcode, product?.title || "");

    if (product) {
      if (retail.highest) product.retailPrice = retail.highest;
      product.source = `${product.source} + retail search`;
      product.notes = [
        product.notes,
        retail.highest ? `Highest retail search price found: $${retail.highest}` : "Retail search did not find a clear price.",
        retail.priceEvidence.length ? `Retail evidence:\n${retail.priceEvidence.slice(0, 8).join("\n\n")}` : ""
      ].filter(Boolean).join("\n\n");
    } else if (retail.bestTitle || retail.highest) {
      const title = retail.bestTitle || `Scanned item ${barcode}`;
      const category = guessCategory(title);
      product = {
        title,
        description: `Retail item found by barcode search. Review title and price before posting.`,
        category,
        retailPrice: retail.highest || estimateRetail(title, category),
        image: "",
        source: "retail search",
        notes: [
          retail.highest ? `Highest retail search price found: $${retail.highest}` : "Retail search found item details but no clear price.",
          retail.priceEvidence.length ? `Retail evidence:\n${retail.priceEvidence.slice(0, 8).join("\n\n")}` : "No price evidence found."
        ].join("\n\n")
      };
    }
  } catch (error) {
    searched.push("Retail web search failed");
  }

  if (product && product.title) {
    if (!product.retailPrice) product.retailPrice = estimateRetail(product.title, product.category);
    return response(200, { found: true, barcode, searched, product });
  }

  return response(200, {
    found: false,
    barcode,
    searched,
    notes: `Searched: ${searched.join(", ")}. No product match found.`
  });
};
